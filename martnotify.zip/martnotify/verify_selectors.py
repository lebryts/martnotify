from bs4 import BeautifulSoup

html = open('selenium_debug.html', 'r', encoding='utf-8').read()
soup = BeautifulSoup(html, 'html.parser')

cards = soup.select('.TRA_con')
print(f'Found {len(cards)} cards with .TRA_con')

for c in cards[:5]:
    style = c.get('style', '')
    if 'hidden' in style or 'height: 0' in style:
        print(f'  [SKIPPED hidden card]')
        continue
    link = c.select_one('h3 a.TRA_link')
    title = link.text.strip() if link else 'NONE'
    card_id = c.get('id', '?')
    
    qty_text = '0'
    val_text = '0'
    details = c.select('.TRA_details')
    if details:
        qty_labels = details[0].select('span.TRA_qty')
        values = details[0].select('span.TRA_clg6')
        for i, lbl in enumerate(qty_labels):
            label = lbl.get_text(strip=True).lower()
            val = values[i].get_text(strip=True) if i < len(values) else ''
            if 'quantity' == label:
                qty_text = val
            elif 'probable order value' in label or 'order value' in label:
                val_text = val
    
    print(f'  Card id={card_id} title="{title}" qty="{qty_text}" val="{val_text}"')
